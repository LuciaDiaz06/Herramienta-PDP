prompt --application/pages/page_00030
begin
--   Manifest
--     PAGE: 00030
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_page.create_page(
 p_id=>30
,p_name=>'Resultados Historia Clinica'
,p_alias=>'RESULTADOS-HISTORIA-CLINICA'
,p_step_title=>'Resultados Historia Clinica'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'HAZBLEIDY.DIAZ@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20240511024820'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(12762569218088840)
,p_name=>'Recomendaciones Generales'
,p_display_sequence=>50
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('   -- RECOMENDACI\00D3N_ID,'),
'    --RESPUESTA_ID,',
unistr('    RECOMENDACI\00D3N,'),
'   -- CATEGORIA_ID,',
'    CATEGORIA,',
'    PONDERACION',
'FROM ',
'    RECOMENDACION',
'    ',
'    WHERE CATEGORIA_ID = 6;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(11394305043501805)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12762665900088841)
,p_query_column_id=>1
,p_column_alias=>unistr('RECOMENDACI\00D3N')
,p_column_display_sequence=>10
,p_column_heading=>unistr('Recomendaci\00F3n')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12762778331088842)
,p_query_column_id=>2
,p_column_alias=>'CATEGORIA'
,p_column_display_sequence=>20
,p_column_heading=>'Categoria'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12762882105088843)
,p_query_column_id=>3
,p_column_alias=>'PONDERACION'
,p_column_display_sequence=>30
,p_column_heading=>'Ponderacion'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13364049246059845)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(12762569218088840)
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11371245017501793)
,p_plug_display_sequence=>40
,p_plug_source=>'<p style="background: #f7f5f5; font-weight: bold; padding: 20px;  font-family: ''Cambria'', serif; font-style: italic; font-size: 24px; text-align: center;">Recomendaciones Sugeridas</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12923949563815992)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11380653829501797)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(11320946023501739)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(11428688633501831)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13363894984059843)
,p_plug_name=>'Nivel de Riesgo'
,p_plug_display_sequence=>20
,p_plug_display_column=>3
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(12762202578088837)
,p_name=>'-'
,p_parent_plug_id=>wwv_flow_imp.id(13363894984059843)
,p_display_sequence=>10
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--xxlarge:t-BadgeList--circular:t-BadgeList--fixed'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  R.EMPRESA_ID, ',
'  SUM(',
'    CASE WHEN R.P51 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 51) ELSE 0 END +',
'    CASE WHEN R.P52 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 52) ELSE 0 END +',
'    CASE WHEN R.P53 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 53) ELSE 0 END +',
'    CASE WHEN R.P54 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 54) ELSE 0 END +',
'    CASE WHEN R.P55 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 55) ELSE 0 END +',
'    CASE WHEN R.P56 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 56) ELSE 0 END +',
'    CASE WHEN R.P57 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 57) ELSE 0 END +',
'    CASE WHEN R.P58 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 58) ELSE 0 END +',
'    CASE WHEN R.P59 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 59) ELSE 0 END +',
'    CASE WHEN R.P60 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 60) ELSE 0 END',
'  ) AS PUNTAJE_TOTAL',
'FROM ',
'  RESPUESTAS R',
'WHERE ',
'  R.EMPRESA_ID = :COD_EMPRESA --AND',
'  --R.FECHA = TO_DATE(:FECHA, ''DD-MM-YYYY'') ',
'GROUP BY ',
'  R.EMPRESA_ID;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(11390730203501803)
,p_query_num_rows=>10
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12762302849088838)
,p_query_column_id=>1
,p_column_alias=>'EMPRESA_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12762467530088839)
,p_query_column_id=>2
,p_column_alias=>'PUNTAJE_TOTAL'
,p_column_display_sequence=>20
,p_column_heading=>'Puntaje Total'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13363382625059838)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(13363894984059843)
,p_region_template_options=>'t-Region--removeHeader:t-Region--textContent:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(11371245017501793)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(13363419093059839)
,p_region_id=>wwv_flow_imp.id(13363382625059838)
,p_chart_type=>'dial'
,p_width=>'250'
,p_height=>'200'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_value_text_type=>'percent'
,p_value_format_type=>'percent'
,p_value_format_scaling=>'auto'
,p_tooltip_rendered=>'Y'
,p_gauge_orientation=>'circular'
,p_gauge_indicator_size=>.5
,p_gauge_inner_radius=>.7
,p_gauge_plot_area=>'on'
,p_gauge_start_angle=>180
,p_gauge_angle_extent=>180
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(13363511887059840)
,p_chart_id=>wwv_flow_imp.id(13363419093059839)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    80 value, ',
'    100 as target ',
'from',
'    dual;'))
,p_items_value_column_name=>'VALUE'
,p_items_max_value=>'TARGET'
,p_items_short_desc_column_name=>'TARGET'
,p_color=>'#008000'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_threshold_values=>'&VALUE., &TARGET.'
,p_threshold_colors=>'yellow,red'
,p_threshold_display=>'all'
,p_reference_line_values=>'&VALUE.'
,p_reference_line_colors=>'Green'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13363957353059844)
,p_plug_name=>'Rango'
,p_plug_display_sequence=>30
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p style="background: #f7f5f5; font-weight: bold; padding: 20px;  font-family: ''Cambria'', serif; font-style: italic; font-size: 24px;">Niveles de Riesgo</p>',
'<strong>Alto - Protegido (80-100%) </strong>:',
unistr('<p> Este rango indica que la entidad cumple de manera sobresaliente con las normativas relativas a la gesti\00F3n de historias cl\00EDnicas. Las organizaciones en este nivel manejan la recolecci\00F3n, uso, almacenamiento y disposici\00F3n de las historias cl\00EDnicas ')
||unistr('de acuerdo con los principios de legalidad, finalidad, veracidad, seguridad, y confidencialidad. Implementan medidas de seguridad avanzadas y pol\00EDticas claras para garantizar la protecci\00F3n de los datos de salud, reduciendo significativamente el riesg')
||unistr('o de incumplimiento y asegurando un alto nivel de confidencialidad y seguridad de la informaci\00F3n del paciente.</p>'),
'<strong>Medio - Intermedio (50-80%) </strong>:',
unistr('<p>Las entidades en este rango muestran un cumplimiento moderado de las regulaciones para la gesti\00F3n de historias cl\00EDnicas. Aunque tienen establecidas ciertas pr\00E1cticas de manejo y protecci\00F3n de los datos de salud, pueden existir brechas en sus siste')
||unistr('mas que requieren atenci\00F3n. Esto puede incluir aspectos como la seguridad en el almacenamiento de datos, procedimientos incompletos para el acceso y la actualizaci\00F3n de la informaci\00F3n, o inconsistencias en la obtenci\00F3n del consentimiento del paciente')
||unistr('. Existe un riesgo moderado de incumplimiento que necesitan abordar para mejorar su conformidad y proteger mejor la informaci\00F3n del paciente.</p>'),
'<strong>Bajo - En riesgo (0-50%) </strong> : ',
unistr('<p>Este rango se\00F1ala un bajo nivel de cumplimiento en la gesti\00F3n de historias cl\00EDnicas. Las entidades aqu\00ED pueden carecer de procedimientos adecuados para el manejo seguro y confidencial de la informaci\00F3n de salud. Las deficiencias pueden incluir fal')
||unistr('ta de medidas de seguridad adecuadas, manejo inadecuado del consentimiento del paciente, o fallas en la actualizaci\00F3n y el acceso a la informaci\00F3n de salud. Este bajo nivel de cumplimiento representa un alto riesgo de incumplimiento con las regulacio')
||unistr('nes legales, lo cual podr\00EDa resultar en sanciones y comprometer la confidencialidad y la integridad de los datos del paciente.</p>')))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
