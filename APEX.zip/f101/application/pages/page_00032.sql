prompt --application/pages/page_00032
begin
--   Manifest
--     PAGE: 00032
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_page.create_page(
 p_id=>32
,p_name=>unistr('Seguridad de Informaci\00F3n')
,p_alias=>unistr('SEGURIDAD-DE-NFORMACI\00D3N')
,p_step_title=>unistr('Seguridad de informaci\00F3n')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'HAZBLEIDY.DIAZ@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20240513233825'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12008157835535125)
,p_plug_name=>'.'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11371245017501793)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_08'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<main role="main">',
'',
'  <!-- Main jumbotron for a primary marketing message or call to action -->',
'  <div class="jumbotron h150">',
'    <div class="container">',
unistr('      <h1 class="display-3">Seguridad de la Informaci\00F3n</h1>'),
unistr('      <p>En esta categor\00EDa se evaluaran medidas t\00E9cnicas, humanas y administrativas que garanticen la seguridad de los datos personales, evitando su adulteraci\00F3n, p\00E9rdida, consulta, uso o acceso no autorizado o fraudulento, acorde a lo estipulado en ')
||'la Ley 1581 de 2012.',
'</p>',
'     <!-- <p><a class="t-Button--hot t t-Button--hot t" href="#" role="button">Learn more &raquo;</a></p>',
'    </div>',
'  </div>',
'',
'   <!-- <div class="container">',
'    <!-- Example row of columns ',
'    <div class="row">',
'      <div class="col-col-6 apex-col-auto">',
'        <h2>Heading</h2>',
'        <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>',
'        <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>',
'      </div>',
'      <div class="col-col-6 apex-col-auto">',
'        <h2>Heading</h2>',
'        <p>Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui. </p>',
'        <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>',
'      </div>',
'      <div class="col-col-6 apex-col-auto">',
'        <h2>Heading</h2>',
'        <p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet ri'
||'sus.</p>',
'        <p><a class="btn btn-secondary" href="#" role="button">View details &raquo;</a></p>',
'      </div>',
'    </div>',
'',
'    <hr>',
'',
'  </div> <!-- /container -->',
'',
'</main>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12329045840700327)
,p_plug_name=>'Por favor lea muy bien las siguientes preguntas y responda SI o NO '
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11371245017501793)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'RESPUESTAS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12373779050700353)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(11427348859501830)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'CHANGE'
,p_button_condition=>'P32_RESPUESTA_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12374175217700353)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(11427348859501830)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'CREATE'
,p_button_condition=>'P32_RESPUESTA_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12373351358700353)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(11427348859501830)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P32_RESPUESTA_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(12374418795700353)
,p_branch_action=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12008092128535124)
,p_name=>'P32_P38'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_prompt=>unistr('\00BFLa entidad ha definido lineamientos, normas y/o est\00E1ndares para controlar el uso y el acceso a los sistemas de informaci\00F3n, las aplicaciones y los dep\00F3sitos de informaci\00F3n con las que cuenta la entidad?')
,p_source=>'P37'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'OPCIONESRESPUESTA1'
,p_lov=>'.'||wwv_flow_imp.id(9564260198175030)||'.'
,p_field_template=>wwv_flow_imp.id(11426491132501829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12329424862700328)
,p_name=>'P32_RESPUESTA_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Respuesta Id'
,p_source=>'RESPUESTA_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(11426260554501828)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12329811764700328)
,p_name=>'P32_EMPRESA_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_default=>':COD_EMPRESA'
,p_item_default_type=>'ITEM'
,p_source=>'EMPRESA_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12330650426700329)
,p_name=>'P32_FECHA'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_prompt=>'Fecha'
,p_source=>'FECHA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(11426260554501828)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12342684116700335)
,p_name=>'P32_P31'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_prompt=>unistr('\00BFExisten pol\00EDticas actualizadas de seguridad de la informaci\00F3n?')
,p_source=>'P31'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'OPCIONESRESPUESTA1'
,p_lov=>'.'||wwv_flow_imp.id(9564260198175030)||'.'
,p_field_template=>wwv_flow_imp.id(11426491132501829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12343094894700335)
,p_name=>'P32_P32'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_prompt=>unistr('\00BFSe realizan auditor\00EDas peri\00F3dicas de seguridad de la informaci\00F3n?')
,p_source=>'P32'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'OPCIONESRESPUESTA1'
,p_lov=>'.'||wwv_flow_imp.id(9564260198175030)||'.'
,p_field_template=>wwv_flow_imp.id(11426491132501829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12343471011700336)
,p_name=>'P32_P33'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_prompt=>unistr('\00BFSe cuenta con sistemas de detecci\00F3n de intrusiones y software antivirus actualizado?')
,p_source=>'P33'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'OPCIONESRESPUESTA1'
,p_lov=>'.'||wwv_flow_imp.id(9564260198175030)||'.'
,p_field_template=>wwv_flow_imp.id(11426491132501829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12343868189700336)
,p_name=>'P32_P34'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_prompt=>unistr('\00BFLa entidad ha definido una pol\00EDtica general de seguridad de la informaci\00F3n?')
,p_source=>'P34'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'OPCIONESRESPUESTA1'
,p_lov=>'.'||wwv_flow_imp.id(9564260198175030)||'.'
,p_field_template=>wwv_flow_imp.id(11426491132501829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12344247405700336)
,p_name=>'P32_P35'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_prompt=>unistr('\00BFSe verifica regularmente la eficacia de las medidas de seguridad implementadas?')
,p_source=>'P35'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'OPCIONESRESPUESTA1'
,p_lov=>'.'||wwv_flow_imp.id(9564260198175030)||'.'
,p_field_template=>wwv_flow_imp.id(11426491132501829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12344635346700336)
,p_name=>'P32_P36'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_prompt=>unistr('\00BFLa entidad ha definido una organizaci\00F3n interna en t\00E9rminos de personas y responsabilidades con el fin de cumplir las pol\00EDticas de seguridad de la informaci\00F3n y documenta estas actividades?')
,p_source=>'P36'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'OPCIONESRESPUESTA1'
,p_lov=>'.'||wwv_flow_imp.id(9564260198175030)||'.'
,p_field_template=>wwv_flow_imp.id(11426491132501829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12345075798700337)
,p_name=>'P32_P37'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_prompt=>unistr('\00BFLa entidad ha definido lineamientos, normas y/o est\00E1ndares para controlar el uso y el acceso a los sistemas de informaci\00F3n, las aplicaciones y los dep\00F3sitos de informaci\00F3n con las que cuenta la entidad?')
,p_source=>'P37'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'OPCIONESRESPUESTA1'
,p_lov=>'.'||wwv_flow_imp.id(9564260198175030)||'.'
,p_field_template=>wwv_flow_imp.id(11426491132501829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12345452409700337)
,p_name=>'P32_P39'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_prompt=>unistr('\00BFLa entidad ha definido lineamientos, normas y/o est\00E1ndares para controlar el uso y el acceso a los sistemas de informaci\00F3n, las aplicaciones y los dep\00F3sitos de informaci\00F3n con las que cuenta la entidad?')
,p_source=>'P39'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'OPCIONESRESPUESTA1'
,p_lov=>'.'||wwv_flow_imp.id(9564260198175030)||'.'
,p_field_template=>wwv_flow_imp.id(11426491132501829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12345869955700337)
,p_name=>'P32_P40'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_prompt=>unistr('\00BFLa entidad verifica de manera interna y/o a trav\00E9s de terceros, peri\00F3dicamente sus procesos de seguridad de la informaci\00F3n y sistemas para asegurar el cumplimiento del modelo?')
,p_source=>'P40'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_named_lov=>'OPCIONESRESPUESTA1'
,p_lov=>'.'||wwv_flow_imp.id(9564260198175030)||'.'
,p_field_template=>wwv_flow_imp.id(11426491132501829)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'1'
,p_attribute_02=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13770315969629946)
,p_name=>'P32_CATEGORIA'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_item_source_plug_id=>wwv_flow_imp.id(12329045840700327)
,p_prompt=>'Categoria'
,p_source=>'CATEGORIA'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:Seguridad de Informaci\00F3n;Seguridad de Informaci\00F3n')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(11426260554501828)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(12007936753535123)
,p_computation_sequence=>10
,p_computation_item=>'P32_EMPRESA_ID'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'ITEM_VALUE'
,p_computation=>'COD_EMPRESA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12375303601700354)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(12329045840700327)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Process form Seguridad de nformaci\00F3n')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>12375303601700354
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12374993169700353)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(12329045840700327)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Seguridad de nformaci\00F3n')
,p_internal_uid=>12374993169700353
);
wwv_flow_imp.component_end;
end;
/
