prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Home'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'span{',
'    font-size:15px;',
'}',
'',
'.box{',
'    padding:60px 0px;',
'}',
'',
'.box-part{',
'    background:#ccc;',
'    border-radius:0;',
'    padding:60px 10px;',
'    margin:5px 0px;',
'    text-align: center;',
'    height: 200px;',
'}',
'.text{',
'    margin:20px 0px;',
'}',
'',
'.fa{',
'     text-align: center;',
'     color:rgba(75, 75, 75, 0.5);',
'}',
'',
'',
'.title{',
'    text-align: center;',
'}',
'',
'.green{color:green;}',
'.orange{color:orange;}',
'.red{color:red;}',
'.black{color:black;}',
'',
'/*******************************************************************************/',
'',
'',
'[class*=''stacked--''] {',
'  position: relative;',
'  -webkit-transition: -webkit-transform 0.3s ease-in-out;',
'  transition: -webkit-transform 0.3s ease-in-out;',
'  transition: transform 0.3s ease-in-out;',
'  transition: transform 0.3s ease-in-out, -webkit-transform 0.3s ease-in-out;',
'  will-change: transform;',
'}',
'[class*=''stacked--'']:before, [class*=''stacked--'']:after {',
'  content: '''';',
'  position: absolute;',
'  top: 0;',
'  right: 0;',
'  bottom: 0;',
'  left: 0;',
'  /*background-color: currentColor;*/',
'  -webkit-transition: -webkit-transform 0.3s ease-in-out;',
'  transition: -webkit-transform 0.3s ease-in-out;',
'  transition: transform 0.3s ease-in-out;',
'  transition: transform 0.3s ease-in-out, -webkit-transform 0.3s ease-in-out;',
'  will-change: transform;',
'}',
'[class*=''stacked--'']:before {',
'  z-index: -1;',
'}',
'[class*=''stacked--'']:after {',
'  z-index: -2;',
'}',
'',
'.stacked--up:before, .stacked--up:after {',
'  -webkit-transform-origin: center bottom;',
'          transform-origin: center bottom;',
'}',
'.stacked--up:hover {',
'  -webkit-transform: translate(0, -5px);',
'          transform: translate(0, -5px);',
'}',
'.stacked--up:hover:before {',
'  -webkit-transform: translate(0, 5px) scale(0.95);',
'          transform: translate(0, 5px) scale(0.95);',
'}',
'.stacked--up:hover:after {',
'  -webkit-transform: translate(0, 10px) scale(0.9);',
'          transform: translate(0, 10px) scale(0.9);',
'}',
'',
'hr{',
'    border: 0;',
'    height: 1px;',
'    /*background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));*/',
'    background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(9, 8, 8, 0.5), rgba(0, 0, 0, 0));',
'}',
'',
'a.bold{',
'    font-weight:bold;',
'}',
'',
'a.bold:hover{',
'    text-decoration: underline;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'13'
,p_last_updated_by=>'HAZBLEIDY.DIAZ@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20240430212815'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7788860318619735)
,p_plug_name=>unistr('PDP - Protecci\00F3n de Datos Personales')
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h1'
,p_plug_template=>wwv_flow_imp.id(11363891017501789)
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>6
,p_plug_display_column=>4
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p> </p>',
'',
'<pre>',
'',
'</pre>',
'',
''))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7789059311619737)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11380653829501797)
,p_plug_display_sequence=>70
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(11320946023501739)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(11428688633501831)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8248856013822903)
,p_plug_name=>'Nosotros'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11342364808501771)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''fa-apex''  icon_class,',
'       :APP_IMAGES || file_name image_url',
'from apex_application_static_files',
'where file_name = ''Lucia''',
'and application_id = :APP_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(8248999628822904)
,p_region_id=>wwv_flow_imp.id(8248856013822903)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3 class="a-CardView-title ">Lucia Diaz</h3>'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>'<p>Ingeniera de Sistemas..</p>'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'ICON_CLASS'
,p_icon_css_classes=>'fa'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'IMAGE_URL'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
,p_media_description=>'Redwood Mountain'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(8249024447822905)
,p_card_id=>wwv_flow_imp.id(8248999628822904)
,p_action_type=>'TITLE'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'https://www.linkedin.com/in/lucia-diaz-mayorga-54086887/'
,p_link_attributes=>'target="_blank"'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7790378199619750)
,p_plug_name=>'.'
,p_parent_plug_id=>wwv_flow_imp.id(8248856013822903)
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11342364808501771)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''fa-apex''  icon_class,',
'       :APP_IMAGES || file_name image_url',
'from apex_application_static_files',
'where file_name = ''Alex.jpg''',
'and application_id = :APP_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(8248690936822901)
,p_region_id=>wwv_flow_imp.id(7790378199619750)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>'<h3 class="a-CardView-title ">Alexander Ramirez</h3>'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>'<p>Ingenier Electronico..</p>'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'ICON_CLASS'
,p_icon_css_classes=>'fa'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'IMAGE_URL'
,p_media_display_position=>'FIRST'
,p_media_appearance=>'WIDESCREEN'
,p_media_sizing=>'COVER'
,p_media_description=>'Redwood Mountain'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(8248732726822902)
,p_card_id=>wwv_flow_imp.id(8248690936822901)
,p_action_type=>'TITLE'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'https://www.linkedin.com/in/lucia-diaz-mayorga-54086887/'
,p_link_attributes=>'target="_blank"'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6059718981470176276)
,p_plug_name=>unistr('\00BF Que es PDP?')
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleB'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11342364808501771)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''fa-apex''  icon_class,',
'       :APP_IMAGES || file_name image_url',
'from apex_application_static_files',
'where file_name = ''PDP''',
'and application_id = :APP_ID'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(8244775961665625)
,p_region_id=>wwv_flow_imp.id(6059718981470176276)
,p_layout_type=>'ROW'
,p_title_adv_formatting=>true
,p_title_html_expr=>unistr('<h3 class="a-CardView-title ">Herramienta de PDP - Protecci\00F3n de Datos Personales</h3>')
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>unistr('<p>Entendemos la importancia cr\00EDtica de cumplir con la norma 1581 de 2012 para proteger los datos personales en el sector salud. Nuestra herramienta proporciona una evaluaci\00F3n detallada del estado actual de tu empresa respecto a esta regulaci\00F3n, iden')
||'tificando oportunidades claras para mejorar y asegurar la conformidad .</p>'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'ICON_CLASS'
,p_icon_css_classes=>'fa'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_media_source_type=>'DYNAMIC_URL'
,p_media_url_column_name=>'IMAGE_URL'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(8245299854665626)
,p_card_id=>wwv_flow_imp.id(8244775961665625)
,p_action_type=>'TITLE'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:::'
,p_link_attributes=>'target="_blank"'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6059746496330757574)
,p_plug_name=>'RDS'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11346218049501779)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_new_grid_column=>false
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_attribute_01=>'STANDARD'
,p_attribute_02=>'N'
,p_attribute_03=>'NO'
,p_attribute_04=>'N'
);
wwv_flow_imp.component_end;
end;
/
