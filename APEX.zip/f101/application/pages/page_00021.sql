prompt --application/pages/page_00021
begin
--   Manifest
--     PAGE: 00021
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_page.create_page(
 p_id=>21
,p_name=>unistr('\00A1Gracias por finalizar!')
,p_alias=>'FINALIZAR-CUESTIONARIO'
,p_page_mode=>'MODAL'
,p_step_title=>unistr('\00A1Gracias por finalizar!')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'HAZBLEIDY.DIAZ@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20240428001557'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10919876800502015)
,p_plug_name=>'Puede dirigirse al Menu Principal o Conocer sus Recomendaciones.'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11371245017501793)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_item_display_point=>'BELOW'
,p_menu_id=>wwv_flow_imp.id(11320946023501739)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(11428688633501831)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10920350310502020)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10919876800502015)
,p_button_name=>'New_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(11427387085501831)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Dashboard'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-home'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10920291851502019)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(10919876800502015)
,p_button_name=>'New'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconRight'
,p_button_template_id=>wwv_flow_imp.id(11427387085501831)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Recomendaciones'
,p_button_redirect_url=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.:::'
,p_icon_css_classes=>'fa-stock-chart'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp.component_end;
end;
/
