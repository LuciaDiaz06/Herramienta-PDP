prompt --application/pages/page_00027
begin
--   Manifest
--     PAGE: 00027
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_page.create_page(
 p_id=>27
,p_name=>unistr('Evaluaci\00F3n X Categorias')
,p_step_title=>unistr('Evaluaci\00F3n X Categorias')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
,p_last_updated_by=>'HAZBLEIDY.DIAZ@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20240504194248'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9353416021703550)
,p_plug_name=>'Prueba2'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11346218049501779)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CATEGORIA_ID, CATEGORIA, DESCRIPCION, VALOR',
'FROM "CATEGORIAS" a',
'WHERE CATEGORIA_ID = 2',
'',
'',
''))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P27_ORDER_BY", "orderBys": [{"key":"CATEGORIA","expr":"\"CATEGORIA\" asc"}]}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(12005738099535101)
,p_region_id=>wwv_flow_imp.id(9353416021703550)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CATEGORIA'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(12006967741535113)
,p_card_id=>wwv_flow_imp.id(12005738099535101)
,p_action_type=>'TITLE'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:8:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11997776782488040)
,p_plug_name=>unistr('Evaluaci\00F3n X Categorias')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11354404291501785)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11998485946488041)
,p_plug_name=>'Prueba1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11346218049501779)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CATEGORIA_ID, CATEGORIA, DESCRIPCION, VALOR',
'FROM "CATEGORIAS" a',
'WHERE CATEGORIA_ID = 1',
'',
'',
''))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P27_ORDER_BY", "orderBys": [{"key":"CATEGORIA","expr":"\"CATEGORIA\" asc"}]}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(11998987570488042)
,p_region_id=>wwv_flow_imp.id(11998485946488041)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CATEGORIA'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(12006870164535112)
,p_card_id=>wwv_flow_imp.id(11998987570488042)
,p_action_type=>'TITLE'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12005822464535102)
,p_plug_name=>'Prueba3'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11346218049501779)
,p_plug_display_sequence=>40
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CATEGORIA_ID, CATEGORIA, DESCRIPCION, VALOR',
'FROM "CATEGORIAS" a',
'WHERE CATEGORIA_ID = 3',
'',
'',
''))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P27_ORDER_BY", "orderBys": [{"key":"CATEGORIA","expr":"\"CATEGORIA\" asc"}]}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(12005927157535103)
,p_region_id=>wwv_flow_imp.id(12005822464535102)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CATEGORIA'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(12007032594535114)
,p_card_id=>wwv_flow_imp.id(12005927157535103)
,p_action_type=>'TITLE'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12006090370535104)
,p_plug_name=>'Prueba4'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11346218049501779)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CATEGORIA_ID, CATEGORIA, DESCRIPCION, VALOR',
'FROM "CATEGORIAS" a',
'WHERE CATEGORIA_ID = 4',
'',
'',
''))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P27_ORDER_BY", "orderBys": [{"key":"CATEGORIA","expr":"\"CATEGORIA\" asc"}]}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(12006146613535105)
,p_region_id=>wwv_flow_imp.id(12006090370535104)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CATEGORIA'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(12007120659535115)
,p_card_id=>wwv_flow_imp.id(12006146613535105)
,p_action_type=>'TITLE'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12006270461535106)
,p_plug_name=>'Prueba5'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11346218049501779)
,p_plug_display_sequence=>70
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CATEGORIA_ID, CATEGORIA, DESCRIPCION, VALOR',
'FROM "CATEGORIAS" a',
'WHERE CATEGORIA_ID = 5',
'',
'',
''))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P27_ORDER_BY", "orderBys": [{"key":"CATEGORIA","expr":"\"CATEGORIA\" asc"}]}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(12006340537535107)
,p_region_id=>wwv_flow_imp.id(12006270461535106)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CATEGORIA'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(12007256297535116)
,p_card_id=>wwv_flow_imp.id(12006340537535107)
,p_action_type=>'TITLE'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:33:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12006451044535108)
,p_plug_name=>'Prueba6'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11346218049501779)
,p_plug_display_sequence=>80
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CATEGORIA_ID, CATEGORIA, DESCRIPCION, VALOR',
'FROM "CATEGORIAS" a',
'WHERE CATEGORIA_ID = 6',
'',
'',
''))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P27_ORDER_BY", "orderBys": [{"key":"CATEGORIA","expr":"\"CATEGORIA\" asc"}]}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(12006581160535109)
,p_region_id=>wwv_flow_imp.id(12006451044535108)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CATEGORIA'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(12007382066535117)
,p_card_id=>wwv_flow_imp.id(12006581160535109)
,p_action_type=>'TITLE'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12006658542535110)
,p_plug_name=>'Prueba7'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11346218049501779)
,p_plug_display_sequence=>100
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT CATEGORIA_ID, CATEGORIA, DESCRIPCION, VALOR',
'FROM "CATEGORIAS" a',
'WHERE CATEGORIA_ID = 7',
'',
'',
''))
,p_query_order_by_type=>'ITEM'
,p_query_order_by=>'{ "itemName": "P27_ORDER_BY", "orderBys": [{"key":"CATEGORIA","expr":"\"CATEGORIA\" asc"}]}'
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(12006738176535111)
,p_region_id=>wwv_flow_imp.id(12006658542535110)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'CATEGORIA'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(12007445746535118)
,p_card_id=>wwv_flow_imp.id(12006738176535111)
,p_action_type=>'TITLE'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:31:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11999401051488042)
,p_name=>'P27_ORDER_BY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(11998485946488041)
,p_item_default=>'CATEGORIA'
,p_display_as=>'NATIVE_HIDDEN'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'Y'
);
wwv_flow_imp.component_end;
end;
/
