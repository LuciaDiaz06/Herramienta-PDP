prompt --application/shared_components/navigation/lists/menu_principal
begin
--   Manifest
--     LIST: MENU PRINCIPAL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(11045845869255871)
,p_name=>'MENU PRINCIPAL'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(11046065967255872)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'MENU PRINCIPAL'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
