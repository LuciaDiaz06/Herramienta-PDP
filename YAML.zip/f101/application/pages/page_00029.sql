prompt --application/pages/page_00029
begin
--   Manifest
--     PAGE: 00029
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_page.create_page(
 p_id=>29
,p_name=>unistr('Resultados An\00E1lisis de Riesgos')
,p_alias=>unistr('RESULTADOS-AN\00C1LISIS-DE-RIESGOS')
,p_step_title=>unistr('Resultados An\00E1lisis de Riesgos')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'HAZBLEIDY.DIAZ@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20240511021203'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12871757566250998)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11380653829501797)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(11320946023501739)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(11428688633501831)
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(12930485202942309)
,p_name=>'Recomendaciones Generales'
,p_template=>wwv_flow_imp.id(11371245017501793)
,p_display_sequence=>40
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('   -- RECOMENDACI\00D3N_ID,'),
'    --RESPUESTA_ID,',
unistr('    RECOMENDACI\00D3N,'),
'   -- CATEGORIA_ID,',
'    CATEGORIA,',
'    PONDERACION',
'FROM ',
'    RECOMENDACION',
'    ',
'    WHERE CATEGORIA_ID = 7;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(11394305043501805)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12930542081942310)
,p_query_column_id=>1
,p_column_alias=>unistr('RECOMENDACI\00D3N')
,p_column_display_sequence=>10
,p_column_heading=>unistr('Recomendaci\00F3n')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12930626297942311)
,p_query_column_id=>2
,p_column_alias=>'CATEGORIA'
,p_column_display_sequence=>20
,p_column_heading=>'Categoria'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12930785915942312)
,p_query_column_id=>3
,p_column_alias=>'PONDERACION'
,p_column_display_sequence=>30
,p_column_heading=>'Ponderacion'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13363145801059836)
,p_plug_name=>'New'
,p_parent_plug_id=>wwv_flow_imp.id(12930485202942309)
,p_plug_display_sequence=>70
,p_plug_source=>'<p style="background: #f7f5f5; font-weight: bold; padding: 20px;  font-family: ''Cambria'', serif; font-style: italic; font-size: 24px; text-align: center;">Recomendaciones Sugeridas</p>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13363010725059835)
,p_plug_name=>'Nivel de Riesgo'
,p_plug_display_sequence=>20
,p_plug_display_column=>3
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(12930104398942306)
,p_name=>'Totales'
,p_parent_plug_id=>wwv_flow_imp.id(13363010725059835)
,p_display_sequence=>10
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--xxlarge:t-BadgeList--circular:t-BadgeList--fixed'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  R.EMPRESA_ID, ',
'  SUM(',
'    CASE WHEN R.P61 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 61) ELSE 0 END +',
'    CASE WHEN R.P62 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 62) ELSE 0 END +',
'    CASE WHEN R.P63 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 63) ELSE 0 END +',
'    CASE WHEN R.P64 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 64) ELSE 0 END +',
'    CASE WHEN R.P65 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 65) ELSE 0 END +',
'    CASE WHEN R.P66 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 66) ELSE 0 END +',
'    CASE WHEN R.P67 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 67) ELSE 0 END +',
'    CASE WHEN R.P68 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 68) ELSE 0 END +',
'    CASE WHEN R.P69 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 69) ELSE 0 END +',
'    CASE WHEN R.P70 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 70) ELSE 0 END',
'  ) AS PUNTAJE_TOTAL',
'FROM ',
'  RESPUESTAS R',
'WHERE ',
'  R.EMPRESA_ID = :COD_EMPRESA --AND',
'  --R.FECHA = TO_DATE(:FECHA, ''DD-MM-YYYY'') ',
'GROUP BY ',
'  R.EMPRESA_ID;'))
,p_query_row_template=>wwv_flow_imp.id(11390730203501803)
,p_query_num_rows=>10
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12930230855942307)
,p_query_column_id=>1
,p_column_alias=>'EMPRESA_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12930311070942308)
,p_query_column_id=>2
,p_column_alias=>'PUNTAJE_TOTAL'
,p_column_display_sequence=>20
,p_column_heading=>'Puntaje Total'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13362552791059830)
,p_plug_name=>'Status'
,p_parent_plug_id=>wwv_flow_imp.id(13363010725059835)
,p_region_template_options=>'t-Region--removeHeader:t-Region--textContent:t-Region--hiddenOverflow'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(11371245017501793)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(13362678997059831)
,p_region_id=>wwv_flow_imp.id(13362552791059830)
,p_chart_type=>'dial'
,p_width=>'250'
,p_height=>'200'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_value_text_type=>'percent'
,p_value_format_type=>'percent'
,p_value_format_scaling=>'auto'
,p_tooltip_rendered=>'Y'
,p_gauge_orientation=>'circular'
,p_gauge_indicator_size=>.5
,p_gauge_inner_radius=>.7
,p_gauge_plot_area=>'on'
,p_gauge_start_angle=>180
,p_gauge_angle_extent=>180
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(13362720801059832)
,p_chart_id=>wwv_flow_imp.id(13362678997059831)
,p_seq=>10
,p_name=>'New'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    80 value, ',
'    100 as target ',
'from',
'    dual;'))
,p_items_value_column_name=>'VALUE'
,p_items_max_value=>'TARGET'
,p_items_short_desc_column_name=>'TARGET'
,p_color=>'#008000'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_threshold_values=>'&VALUE., &TARGET.'
,p_threshold_colors=>'yellow,red'
,p_threshold_display=>'all'
,p_reference_line_values=>'&VALUE.'
,p_reference_line_colors=>'Green'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13363299285059837)
,p_plug_name=>'Rangos'
,p_plug_display_sequence=>30
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p style="background: #f7f5f5; font-weight: bold; padding: 20px;  font-family: ''Cambria'', serif; font-style: italic; font-size: 24px;">Niveles de Riesgo</p>',
'',
'<strong>Alto - Protegido (80-100%) </strong>: ',
unistr(' <p>Este rango indica que la entidad realiza un an\00E1lisis de riesgos de manera exhaustiva y efectiva. Las organizaciones en este nivel han implementado un proceso sistem\00E1tico y continuo para identificar, evaluar y gestionar los riesgos asociados al tr')
||unistr('atamiento de datos personales. Utilizan herramientas y metodolog\00EDas avanzadas para asegurar que los riesgos est\00E1n siendo identificados y mitigados adecuadamente, lo cual incluye la evaluaci\00F3n de amenazas, vulnerabilidades y posibles impactos, garanti')
||unistr('zando as\00ED un alto grado de cumplimiento y un bajo riesgo de infracci\00F3n de la normativa.</p>'),
' <strong>Medio - Intermedio (50-80%) </strong>:',
unistr(' <p>Las entidades en este rango tienen procedimientos de an\00E1lisis de riesgos implementados, pero pueden ser parciales o no completamente efectivos. Aunque reconocen la importancia del an\00E1lisis de riesgos y han comenzado a aplicar algunas medidas de c')
||unistr('ontrol, a\00FAn existen \00E1reas que requieren mejoras para gestionar de manera m\00E1s efectiva los riesgos asociados al tratamiento de datos personales. El riesgo de incumplimiento es moderado, y es necesario fortalecer la aplicaci\00F3n de medidas de mitigaci\00F3n ')
||unistr('o la cobertura del an\00E1lisis para alcanzar un nivel \00F3ptimo de cumplimiento.</p>'),
' <strong>Bajo - En riesgo (0-50%) </strong> :',
unistr('<p>En este rango, las entidades presentan deficiencias significativas en su capacidad para realizar un an\00E1lisis de riesgos adecuado. Pueden carecer de un proceso formal para identificar y gestionar los riesgos, o sus esfuerzos pueden ser espor\00E1dicos ')
||unistr('e ineficaces. La falta de un an\00E1lisis de riesgos completo y sistem\00E1tico conlleva un alto riesgo de incumplimiento, ya que no se identifican adecuadamente las amenazas ni se implementan las medidas de control necesarias para proteger los datos persona')
||'les. Esto pone a la entidad en riesgo de sufrir incidentes de seguridad y de incumplir con la ley.</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
