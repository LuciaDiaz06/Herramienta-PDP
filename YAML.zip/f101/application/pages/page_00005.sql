prompt --application/pages/page_00005
begin
--   Manifest
--     PAGE: 00005
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_page.create_page(
 p_id=>5
,p_name=>'Folders'
,p_step_title=>'Folders'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'span{',
'    font-size:15px;',
'}',
'',
'.box{',
'    padding:60px 0px;',
'}',
'',
'.box-part{',
'    background:#ccc;',
'    border-radius:0;',
'    padding:60px 10px;',
'    margin:5px 0px;',
'    text-align: center;',
'    height: 250px;',
'}',
'.text{',
'    margin:20px 0px;',
'}',
'',
'.fa{',
'     text-align: center;',
'     color:rgba(75, 75, 75, 0.5);',
'}',
'/***************************/',
'',
'/*',
'.box-part{',
'    background:#fff;',
'    border-radius:2px;',
'    padding:40px 10px;',
'    margin:30px 0px;',
'    height: 500px;',
'}*/',
'',
'.title{',
'    text-align: center;',
'}',
'',
'.green{color:green;}',
'.orange{color:orange;}',
'.red{color:red;}',
'.black{color:black;}',
'',
'/*******************************************************************************/',
'',
'',
'[class*=''stacked--''] {',
'  position: relative;',
'  -webkit-transition: -webkit-transform 0.3s ease-in-out;',
'  transition: -webkit-transform 0.3s ease-in-out;',
'  transition: transform 0.3s ease-in-out;',
'  transition: transform 0.3s ease-in-out, -webkit-transform 0.3s ease-in-out;',
'  will-change: transform;',
'}',
'[class*=''stacked--'']:before, [class*=''stacked--'']:after {',
'  content: '''';',
'  position: absolute;',
'  top: 0;',
'  right: 0;',
'  bottom: 0;',
'  left: 0;',
'  /*background-color: currentColor;*/',
'  -webkit-transition: -webkit-transform 0.3s ease-in-out;',
'  transition: -webkit-transform 0.3s ease-in-out;',
'  transition: transform 0.3s ease-in-out;',
'  transition: transform 0.3s ease-in-out, -webkit-transform 0.3s ease-in-out;',
'  will-change: transform;',
'}',
'[class*=''stacked--'']:before {',
'  z-index: -1;',
'}',
'[class*=''stacked--'']:after {',
'  z-index: -2;',
'}',
'',
'.stacked--up:before, .stacked--up:after {',
'  -webkit-transform-origin: center bottom;',
'          transform-origin: center bottom;',
'}',
'.stacked--up:hover {',
'  -webkit-transform: translate(0, -5px);',
'          transform: translate(0, -5px);',
'}',
'.stacked--up:hover:before {',
'  -webkit-transform: translate(0, 5px) scale(0.95);',
'          transform: translate(0, 5px) scale(0.95);',
'}',
'.stacked--up:hover:after {',
'  -webkit-transform: translate(0, 10px) scale(0.9);',
'          transform: translate(0, 10px) scale(0.9);',
'}',
'',
'hr{',
'    border: 0;',
'    height: 1px;',
'    /*background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));*/',
'    background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(9, 8, 8, 0.5), rgba(0, 0, 0, 0));',
'}',
'',
'a.bold{',
'    font-weight:bold;',
'}',
'',
'a.bold:hover{',
'    text-decoration: underline;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'10'
,p_last_updated_by=>'HAZBLEIDY.DIAZ@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20240515203144'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11030665645661553)
,p_plug_name=>'Documentos'
,p_region_template_options=>'#DEFAULT#:t-Region--removeHeader:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11371245017501793)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_columnas pls_integer := 4;',
'    l_total_fils pls_integer := 0;',
'    l_bootstrap_columns pls_integer := 18 / l_columnas;',
'    ',
'    cursor cursor_documentos is',
'    select id, folder, descripcion',
'    from documentos',
'    order by id desc;',
'    ',
'    type lty_cursor is table of cursor_documentos%rowtype index by binary_integer;',
'    ',
'    it_docs lty_cursor;',
'begin ',
'',
'htp.p(''<div class="row">'');--row default',
'',
'    open cursor_documentos;',
'    ',
'    fetch cursor_documentos bulk collect into it_docs;',
'    ',
'        for i in it_docs.first .. it_docs.last ',
'            loop',
'            ',
'            htp.p(''<div class="col col-'' || l_bootstrap_columns ||'' card card-3 stacked up"> '');',
'            ',
'                htp.p(''<div class="box-part text-center">'');',
'',
'                    htp.p(''<div class="title">'');',
'                        htp.p(''<h3>''|| it_docs(i).folder || ''</h3>'' );',
'                    htp.p(''</div>'');',
'',
'                    htp.p(''<div class="text">'');',
'                        htp.p(''<p>''|| it_docs(i).descripcion || ''</p>'' );',
'                        htp.p(''<a href="f?p='' || v(''APP_ID'') || '':14:'' || v(''APP_SESSION'') || ''::NO:RP,14:P14_CATEGORIA:'' ||it_docs(i).folder ||''"> Ver documentos </a> <br>'');',
'                       ',
'                    htp.p(''</div>'');',
'                    ',
'                    ',
'',
'',
'                htp.p(''</div>'');',
'            ',
'            htp.p(''</div>'');',
'            ',
'            l_total_fils := l_total_fils + 1;',
'            ',
'                if MOD(l_total_fils , l_columnas) = 0 then',
'                    htp.p(''</div> <!-- Primer row cerrado -->',
'                          <div class="row">'');',
'                end if;',
'            ',
'            ',
'            end loop;',
'            ',
'            htp.p(''</div>'');',
'    ',
'    close cursor_documentos;',
'end;'))
,p_plug_source_type=>'NATIVE_PLSQL'
);
wwv_flow_imp.component_end;
end;
/
