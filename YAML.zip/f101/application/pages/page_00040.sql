prompt --application/pages/page_00040
begin
--   Manifest
--     PAGE: 00040
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_page.create_page(
 p_id=>40
,p_name=>'Resultados Derechos de los Titulares'
,p_alias=>'RESULTADOS-DERECHOS-DE-LOS-TITULARES'
,p_step_title=>'Resultados Derechos de los Titulares'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'HAZBLEIDY.DIAZ@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20240506014107'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(12760807750088823)
,p_name=>'-'
,p_template=>wwv_flow_imp.id(11371245017501793)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--xxlarge:t-BadgeList--circular:t-BadgeList--fixed'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  R.EMPRESA_ID, ',
'  SUM(',
'    CASE WHEN R.P21 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 21) ELSE 0 END +',
'    CASE WHEN R.P22 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 22) ELSE 0 END +',
'    CASE WHEN R.P23 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 23) ELSE 0 END +',
'    CASE WHEN R.P24 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 24) ELSE 0 END +',
'    CASE WHEN R.P25 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 25) ELSE 0 END +',
'    CASE WHEN R.P26 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 26) ELSE 0 END +',
'    CASE WHEN R.P27 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 27) ELSE 0 END +',
'    CASE WHEN R.P28 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 28) ELSE 0 END +',
'    CASE WHEN R.P29 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 29) ELSE 0 END +',
'    CASE WHEN R.P30 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 30) ELSE 0 END',
'  ) AS PUNTAJE_TOTAL',
'FROM ',
'  RESPUESTAS R',
'WHERE ',
'  R.EMPRESA_ID = :COD_EMPRESA --AND',
' -- R.FECHA = TO_DATE(:FECHA, ''DD-MM-YYYY'') ',
'GROUP BY ',
'  R.EMPRESA_ID;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(11390730203501803)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12760924954088824)
,p_query_column_id=>1
,p_column_alias=>'EMPRESA_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12761040275088825)
,p_query_column_id=>2
,p_column_alias=>'PUNTAJE_TOTAL'
,p_column_display_sequence=>20
,p_column_heading=>'Puntaje Total'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(12761141770088826)
,p_name=>'New'
,p_template=>wwv_flow_imp.id(11371245017501793)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('   -- RECOMENDACI\00D3N_ID,'),
'    --RESPUESTA_ID,',
unistr('    RECOMENDACI\00D3N,'),
'   -- CATEGORIA_ID,',
'    CATEGORIA,',
'    PONDERACION',
'FROM ',
'    RECOMENDACION',
'    ',
'    WHERE CATEGORIA_ID = 3;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(11394305043501805)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12761207428088827)
,p_query_column_id=>1
,p_column_alias=>unistr('RECOMENDACI\00D3N')
,p_column_display_sequence=>10
,p_column_heading=>unistr('Recomendaci\00F3n')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12761346325088828)
,p_query_column_id=>2
,p_column_alias=>'CATEGORIA'
,p_column_display_sequence=>20
,p_column_heading=>'Categoria'
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12761457341088829)
,p_query_column_id=>3
,p_column_alias=>'PONDERACION'
,p_column_display_sequence=>30
,p_column_heading=>'Ponderacion'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12873455746285588)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11380653829501797)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(11320946023501739)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(11428688633501831)
);
wwv_flow_imp.component_end;
end;
/
