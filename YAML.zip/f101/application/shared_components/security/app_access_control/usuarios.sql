prompt --application/shared_components/security/app_access_control/usuarios
begin
--   Manifest
--     ACL ROLE: Usuarios
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(8069171173574934)
,p_static_id=>'USUARIOS'
,p_name=>'Usuarios'
,p_version_scn=>1866433163
);
wwv_flow_imp.component_end;
end;
/
