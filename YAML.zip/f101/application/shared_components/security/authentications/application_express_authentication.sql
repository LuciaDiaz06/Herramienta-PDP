prompt --application/shared_components/security/authentications/application_express_authentication
begin
--   Manifest
--     AUTHENTICATION: Application Express Authentication
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(11320626106501737)
,p_name=>'Application Express Authentication'
,p_scheme_type=>'NATIVE_APEX_ACCOUNTS'
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
