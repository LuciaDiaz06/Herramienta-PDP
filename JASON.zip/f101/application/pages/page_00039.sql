prompt --application/pages/page_00039
begin
--   Manifest
--     PAGE: 00039
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_page.create_page(
 p_id=>39
,p_name=>unistr('Resultados Principios de la Protecci\00F3n de Datos')
,p_alias=>unistr('RESULTADOS-PRINCIPIOS-DE-LA-PROTECCI\00D3N-DE-DATOS')
,p_step_title=>unistr('Resultados Principios de la Protecci\00F3n de Datos')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
,p_last_updated_by=>'HAZBLEIDY.DIAZ@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20240516001837'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(12759175523088806)
,p_name=>'-'
,p_template=>wwv_flow_imp.id(11371245017501793)
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--xxlarge:t-BadgeList--circular:t-BadgeList--fixed'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
'  R.EMPRESA_ID, ',
'  SUM(',
'    CASE WHEN R.P1 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 1) ELSE 0 END +',
'    CASE WHEN R.P2 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 2) ELSE 0 END +',
'    CASE WHEN R.P3 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 3) ELSE 0 END +',
'    CASE WHEN R.P4 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 4) ELSE 0 END +',
'    CASE WHEN R.P5 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 5) ELSE 0 END +',
'    CASE WHEN R.P6 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 6) ELSE 0 END +',
'    CASE WHEN R.P7 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 7) ELSE 0 END +',
'    CASE WHEN R.P8 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 8) ELSE 0 END +',
'    CASE WHEN R.P9 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 9) ELSE 0 END +',
'    CASE WHEN R.P10 = ''SI'' THEN (SELECT PONDERACION FROM PREGUNTAS WHERE PREGUNTA_ID = 10) ELSE 0 END ',
'    ',
'  ) AS PUNTAJE_TOTAL',
'FROM ',
'  RESPUESTAS R',
'WHERE ',
'  R.EMPRESA_ID = :COD_EMPRESA --AND',
'  --R.FECHA = TO_DATE(:FECHA, ''DD-MM-YYYY'') ',
'GROUP BY ',
'  R.EMPRESA_ID;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(11390730203501803)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12759284787088807)
,p_query_column_id=>1
,p_column_alias=>'EMPRESA_ID'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12759365248088808)
,p_query_column_id=>2
,p_column_alias=>'PUNTAJE_TOTAL'
,p_column_display_sequence=>20
,p_column_heading=>'Puntaje Total'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(12759479512088809)
,p_name=>'Recomendaciones Sugeridas'
,p_template=>wwv_flow_imp.id(11371245017501793)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('   -- RECOMENDACI\00D3N_ID,'),
'    --RESPUESTA_ID,',
unistr('    RECOMENDACI\00D3N,'),
'   -- CATEGORIA_ID,',
'    CATEGORIA,',
'    PONDERACION',
'FROM ',
'    RECOMENDACION',
'    ',
'    WHERE CATEGORIA_ID = 1;'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(11394305043501805)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12759711450088812)
,p_query_column_id=>1
,p_column_alias=>unistr('RECOMENDACI\00D3N')
,p_column_display_sequence=>30
,p_column_heading=>unistr('Recomendaci\00F3n')
,p_use_as_row_header=>'N'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12759945366088814)
,p_query_column_id=>2
,p_column_alias=>'CATEGORIA'
,p_column_display_sequence=>50
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(12760030163088815)
,p_query_column_id=>3
,p_column_alias=>'PONDERACION'
,p_column_display_sequence=>60
,p_column_heading=>'Ponderacion'
,p_use_as_row_header=>'N'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12775588138138949)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(11380653829501797)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(11320946023501739)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(11428688633501831)
);
wwv_flow_imp.component_end;
end;
/
