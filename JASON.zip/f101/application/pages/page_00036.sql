prompt --application/pages/page_00036
begin
--   Manifest
--     PAGE: 00036
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_page.create_page(
 p_id=>36
,p_name=>'Radar'
,p_alias=>'RADAR'
,p_step_title=>'Radar'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
,p_last_updated_by=>'HAZBLEIDY.DIAZ@ORACLE.COM'
,p_last_upd_yyyymmddhh24miss=>'20240511152625'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13528629522758236)
,p_plug_name=>'Radar'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(11371245017501793)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(13529021514758238)
,p_region_id=>wwv_flow_imp.id(13528629522758236)
,p_chart_type=>'radar'
,p_width=>'650'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'none'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(13530774038758241)
,p_chart_id=>wwv_flow_imp.id(13529021514758238)
,p_seq=>10
,p_name=>unistr('Categoria Prinicpios de Protecci\00F3n de Datos')
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT ',
unistr('    CATEGORIA,  -- Usamos ''categoria'' como el nombre de la categor\00EDa'),
'    AVG(',
unistr('        (SELECT AVG(CASE WHEN r.P1 = ''s\00ED'' THEN 1 ELSE 0 END) FROM respuestas r WHERE r.EMPRESA_ID = resp.EMPRESA_ID) +'),
unistr('        (SELECT AVG(CASE WHEN r.P2 = ''s\00ED'' THEN 1 ELSE 0 END) FROM respuestas r WHERE r.EMPRESA_ID = resp.EMPRESA_ID) +'),
unistr('        -- Contin\00FAa agregando consultas para cada columna de respuesta hasta P60'),
unistr('        (SELECT AVG(CASE WHEN r.P60 = ''s\00ED'' THEN 1 ELSE 0 END) FROM respuestas r WHERE r.EMPRESA_ID = resp.EMPRESA_ID)'),
unistr('    ) / 60 AS tasa_de_cumplimiento  -- Aseg\00FArate de ajustar el divisor al n\00FAmero de preguntas activas'),
'FROM ',
'    respuestas resp',
'JOIN ',
'    preguntas preg ON resp.respuesta_id = preg.pregunta_id',
'JOIN ',
'    categorias cat ON preg.categoria_id = cat.categoria_id',
'WHERE ',
'    resp.empresa_id = 2 AND cat.categoria_id = 1  -- Filtrando por categoria_id 1',
'GROUP BY ',
'    CATEGORIA '))
,p_series_type=>'line'
,p_items_value_column_name=>'TASA_DE_CUMPLIMIENTO'
,p_group_short_desc_column_name=>'CATEGORIA'
,p_items_label_column_name=>'CATEGORIA'
,p_line_type=>'auto'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(13529596412758240)
,p_chart_id=>wwv_flow_imp.id(13529021514758238)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>true
,p_zoom_order_weeks=>true
,p_zoom_order_months=>true
,p_zoom_order_quarters=>true
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(13530159295758241)
,p_chart_id=>wwv_flow_imp.id(13529021514758238)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>true
,p_zoom_order_weeks=>true
,p_zoom_order_months=>true
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp.component_end;
end;
/
