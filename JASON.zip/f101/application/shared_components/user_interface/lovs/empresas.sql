prompt --application/shared_components/user_interface/lovs/empresas
begin
--   Manifest
--     EMPRESAS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.3'
,p_default_workspace_id=>7467965552404627
,p_default_application_id=>101
,p_default_id_offset=>7855078094276037
,p_default_owner=>'WKSP_HERRAMIENTAPDP'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(11019796493515382)
,p_lov_name=>'EMPRESAS'
,p_lov_query=>'.'||wwv_flow_imp.id(11019796493515382)||'.'
,p_location=>'STATIC'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(11020047266515386)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'RADIOFAM'
,p_lov_return_value=>'RADIOFAM'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(11020451866515387)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'EVALUADOR 1'
,p_lov_return_value=>'EVALUADOR 1'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(11020885149515387)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'EVALUADOR 2'
,p_lov_return_value=>'EVALUADOR 2'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(11021247595515387)
,p_lov_disp_sequence=>4
,p_lov_disp_value=>'EVALUADOR 3'
,p_lov_return_value=>'EVALUADOR 3'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(11021657852515388)
,p_lov_disp_sequence=>5
,p_lov_disp_value=>'EVALUADOR 4'
,p_lov_return_value=>'EVALUADOR 4'
);
wwv_flow_imp.component_end;
end;
/
